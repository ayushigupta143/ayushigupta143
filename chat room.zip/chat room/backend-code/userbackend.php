
<?php

include_once 'connection.php';

session_start();


$action=$_REQUEST['action']; 
switch ($action) {
    case 'Registration-form':
        $photo="photo/";
    $date=date("d/m/y");
date_default_timezone_set("asia/kolkata");
$time=date("h:i:sa");
$datetime=$date." ".$time; 
$status='false';
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$mobile=$_POST['Mobile']; 
$profile=$_FILES['file']['name'];
$profiletemp=$_FILES['file']['tmp_name'];
$gender=$_POST['Gender'];
$email=$_POST['Email'];
$password=$_POST['Password'];

// INSERT INTO table _name(column name) VALUES( values name);

$insert="insert into register(fname,lname,mobile,profile,gender,email,password,date,time,status) values('$fname','$lname','$mobile','$profile','$gender','$email','$password','$date','$time','$status')";
if(mysqli_query($connection,$insert))
{
    
    move_uploaded_file($profiletemp,"photo/".$profile);
    //echo "IMAGE SUCCESSFULLY STORED ";
    echo '<script>alert("User Registerd Successfully | Please goto  index.html for user Login")</script>';
    header("refresh:0;url=http://localhost/chat%20room/index.html");
}
else{
    echo "error";
}

        break;
        case 'Login-form':
        $Email=$_POST['Email'];
        $Password=$_POST['Password'];
        $status="true";
    
        $select="SELECT email,password FROM register where email='$Email'";
        //$query=mysqli_query($connection,$select);
        $query=$connection->query($select); 
            //echo "data ok";

    
        if (mysqli_num_rows($query)>0) 
        {
           $row=$query->fetch_assoc();
            {
               if($row['email']==$Email) 
               {
                if($row['password']==$Password)
                {
                   // note: Sesson start krna  hoga . 
                   //echo 'User Online';

                    $update="UPDATE register SET status = '$status' WHERE email='$Email'";

                    if(mysqli_query($connection,$update))
                    {
                        //echo "user true";
                         $_SESSION['email']=$Email;
                        header("refresh:0;url=http://localhost/chat%20room/home.php");

                    }

                    
                } 
                else {
                     echo '<script>alert("Passsword Wrong")</script>';
                     header("refresh:0;url=http://localhost/chat%20room/");
                    //echo "Passsword Wrong";
                }
                
                } 
            }
        } else {
       
            echo '<script>alert("Your Email Address is Not Registered. Please Register at Chat Box")</script>';
            header("refresh:0;url=http://localhost/chat%20room/index.html");
                    //echo "Please register on chat box";
                }
        
        




            break;
   case 'logout':

                 $email=$_SESSION['email'];                   
                 $status='false';
                 $update="update register set status='$status' where email='$email'";
                 if (mysqli_query($connection,$update)) {
                        session_destroy();
                        echo '<script>alert("user logout")</script>';
                        header("refresh:0;url=http://localhost/chat%20room/index.html");

                    }   

       break;
    default:
        // code...
        break;
}

?>