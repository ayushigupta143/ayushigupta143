<html>
    <head>
    <link rel="stylesheet" type="text/css" href="css/home.css">
    </head>
    <body>
        <h1>Chat with your frends</h1>
        <?php
header("refresh: 3");
        include_once 'backend-code/connection.php';
        session_start();
        $email=$_SESSION['email'];
        $sql = "select * from register where email='$email'";
        $result = $connection->query($sql);
        $row2 = $result->fetch_assoc();
            
        ?>
        <h2>Welcome...   <?php echo $row2["fname"]." ".$row2["lname"]; ?></h2>
        <a href="backend-code/userbackend.php?action=logout">Logout</a>

        <?php
            
            $select="SELECT * FROM register ORDER BY email DESC";
            if($query=mysqli_query($connection,$select))
             {
                //echo "ok";       
            } 
             else 
            { 

                    echo "not";
            }
        ?>


        <div class="outer">
            <?php
           
            while ($row=mysqli_fetch_assoc($query)) {
            
                if($row['email']!=$email)
                {
            ?>
                    <div class="row">
                        <a class="link1" href="chat.php?reciver=<?php echo $row['email']; ?>">
                            <div class="pic">
                                <img src="backend-code/photo/<?php echo $row["profile"];?>" />
                            </div>
                            <div class="details">
                            <span class="online"> </span>
                                <?php
                                    if($row['status']=="true")
                                    {
                                ?>
                                <span class="online"> &nbsp; </span>
                                <?php
                                    }
                                    else
                                    {
                                ?>
                                <span class="offline"> &nbsp; </span>
                                <?php
                                    }
                                ?>
                                <span class="name"><?php echo $row["fname"]." ".$row["lname"]; ?></span>
                                <br/><br/>
                                <span class="lastseen"><?php echo $row["date"]." ".$row["time"]; ?></span>
                                
                            </div>
                        </a>
                    </div>
            <?php
            }
            }
            ?>
        </div>


    </body>
</html>






