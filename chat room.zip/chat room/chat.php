<?php

include 'backend-code/connection.php';
session_start();
 $email=$_SESSION['email'];
 $reciver=$_REQUEST['reciver'];
  $date=date("d/m/y");
date_default_timezone_set("asia/kolkata");
$time=date("h:i:sa");
$datetime=$date." ".$time; 
header("refresh: 10");


 ?>
<head>
	<link rel="stylesheet" type="text/css" href="css/chat.css">
</head>
 <body>
	<h1>Chat with your frends</h1>
        <?php
        include_once 'backend-code/connection.php';
       
        $email=$_SESSION['email'];
        $sql = "select * from register where email='$email'";
        $result = $connection->query($sql);
        $row2 = $result->fetch_assoc();
            
         
        ?>
        <h2>User: <?php echo $row2["fname"]." ".$row2["lname"]; ?></h2>
        <a href="backend-code/userbackend.php?action=logout">Logout</a>
        <a href="#">Home</a>

	<div class="outer">
		<div class="messages">
			<?php
				$sql="select * from message where (sender='$email' and receiver='$reciver') or (sender='$reciver' and receiver='$email')";
				$result = $connection->query($sql);
		
				while($row1 = $result->fetch_assoc()) 
				{
			?>
			
				<div class="<?php if($row1['sender']==$email){ echo "sender"; }else {echo "receiver";} ?>"><span><?php echo $row1['message']; ?></span></div>

			<?php
				}
			?>


		</div>
		<div class="msgform">
			<form  method="post">
				<textarea name="msg" placeholder="Click to type message..."  required></textarea>
				<input type="submit" id="button" name="submit" value="Send">
			</form>
			<?php 
			if (isset($_POST['submit'])) {
				$email=$_SESSION['email'];
 				$reciver=$_REQUEST['reciver'];
				$msg=$_POST['msg'];
				$insert="insert into message(sender,receiver,message,date,time) values('$email','$reciver','$msg','$date','$time')";
				if (mysqli_query($connection,$insert)) {
								echo "message send";
								 $email=$_SESSION['email'];
 								 $reciver1=$_REQUEST['reciver'];
								header("refresh:0;url=http://localhost/chat%20room/chat.php?reciver=".$reciver1);
				} else {
					echo " message failed ";
				}
			}
			?>
		</div>
	</div>
</body>