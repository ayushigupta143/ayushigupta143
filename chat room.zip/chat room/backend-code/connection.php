<?php 


// hostname , useername , password , databasename 

$hostname="localhost";
$username="root";
$password="";
$database="chatroom";

$connection=mysqli_connect($hostname,$username,$password,$database);
if ($connection) {
	//echo "connection ok";

}
else {
	echo "connection failed";
}

?>